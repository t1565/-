import tkinter as tk
from tkinter import filedialog, messagebox
import os
import platform

# Optional: Wallpaper change for Windows
def set_wallpaper(image_path):
    try:
        if platform.system() == "Windows":
            import ctypes
            ctypes.windll.user32.SystemParametersInfoW(20, 0, image_path, 3)
            messagebox.showinfo("Success", "Wallpaper changed successfully!")
        else:
            messagebox.showwarning("Unsupported", "Wallpaper changing is only supported on Windows in this version.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# System info popup
def show_system_info():
    info = f"System: {platform.system()}\nRelease: {platform.release()}\nVersion: {platform.version()}\nMachine: {platform.machine()}"
    messagebox.showinfo("System Info", info)

# Select wallpaper and apply
def choose_wallpaper():
    file_path = filedialog.askopenfilename(title="Select Image", filetypes=[("Image Files", "*.jpg *.png *.bmp")])
    if file_path:
        set_wallpaper(file_path)

# Main window
root = tk.Tk()
root.title("PC Customizer - Python Desktop App")
root.geometry("400x300")
root.config(bg="#20232a")

# Buttons
title_label = tk.Label(root, text="PC Customizer", font=("Arial", 18, "bold"), bg="#20232a", fg="white")
title_label.pack(pady=20)

btn_wallpaper = tk.Button(root, text="Change Wallpaper", font=("Arial", 12), width=20, command=choose_wallpaper)
btn_wallpaper.pack(pady=10)

btn_sysinfo = tk.Button(root, text="Show System Info", font=("Arial", 12), width=20, command=show_system_info)
btn_sysinfo.pack(pady=10)

btn_exit = tk.Button(root, text="Exit", font=("Arial", 12), width=20, command=root.quit)
btn_exit.pack(pady=20)

root.mainloop()
